var map;
var providerMarkers;

document.addEventListener("DOMContentLoaded", function(event) {
    'use strict'

    feather.replace({ 'aria-hidden': 'true' })

    if (typeof userLocation !== 'undefined') {
        map = new ol.Map({
            target: 'map',
            layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
            ],
            interactions: ol.interaction.defaults({mouseWheelZoom:false}),
            controls: [
                new ol.control.Zoom()
            ],
            view: new ol.View({
                center: ol.proj.fromLonLat([userLocation.lon, userLocation.lat]),
                zoom: 12
            })
        });
    }

    if(map) {
        //Create customer marker
        var customerMarker = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: new ol.style.Style({
              image: new ol.style.Icon({
                anchor: [0.5, 1],
                scale: 0.1,
                src: '../src/ineed-logo.png'
              })
            })
        });
        map.addLayer(customerMarker);

        var marker = new ol.Feature(new ol.geom.Point(ol.proj.fromLonLat([userLocation.lon, userLocation.lat])));
        customerMarker.getSource().addFeature(marker);

        providerMarkers = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: new ol.style.Style({
              image: new ol.style.Icon({
                anchor: [0.5, 1],
                scale: 0.3,
                src: 'https://icon-library.com/images/map-marker-icon-vector/map-marker-icon-vector-19.jpg'
              })
            })
        });
        map.addLayer(providerMarkers);

        //Popup
        var container = document.getElementById('popup');
        var content = document.getElementById('popup-content');
        var closer = document.getElementById('popup-closer');
       
        var overlay = new ol.Overlay({
            element: container,
            autoPan: true,
            autoPanAnimation: {
                duration: 250
            }
        });
        map.addOverlay(overlay);
       
        closer.onclick = function() {
            overlay.setPosition(undefined);
            closer.blur();
            return false;
        };
        
        map.on('singleclick', function (event) {
            if (map.hasFeatureAtPixel(event.pixel) === true) {
                var feature;
                feature = map.forEachFeatureAtPixel(event.pixel, function (feat, layer) {
                    if (feat.data != undefined)
                        return feat;
                });
                if(feature != undefined) {
                    var coordinate = event.coordinate;
                    content.innerHTML = `<a href="#">${feature.data.first_name}, ${feature.data.last_name}</a><br /><b>Distance:</b> ${parseFloat(feature.data.distance).toFixed( 2 )}Km.`;
                    overlay.setPosition(coordinate);
                }
            } else {
                overlay.setPosition(undefined);
                closer.blur();
            }
        });       
    }

    $("#service_type").change(function () {
        var serviceType = $( "#service_type option:selected" ).val();
        if(serviceType != "") {
            getServices(serviceType);
        }
    });

    $("#btn_search").click(function() {
        searchProviders();
    });
});

function getServices(serviceType) {
    $.getJSON( `../api/getservices/${serviceType}`, function( data ) {
        var items = [];
        $.each( data, function( key, val ) {
            items.push( "<option value='" + val.id_service + "'>" + val.service_name + "</option>" );
        });
       
        $("#service").find('option').not(':first').remove();
        $("#service").append(items);
    });
}

function searchProviders() {
    var idCustomer = $("#customer").val();
    var idService = $( "#service option:selected" ).val();
    var distance = $( "#distance option:selected" ).val(); 
    var language = $( "#language option:selected" ).val();
    //Remove old markers
    removeMarkers();
    $.getJSON( `../api/getproviders/${idCustomer}/${idService}/${distance}/${language}`, function( data ) {
        $.each( data, function( key, val ) {
            //[{"id_service_provider":"1","first_name":"Isabela","last_name":"Pamplona","telephone":"1234567890","address":"8575 8e Avenue","status":"ACT","lat":"45.5657","lon":"-73.6198","id_account":"7","distance":"9.211576050586917"}]
            //Create provider markers
            buildMarker(val);
        });
    });
}

function buildMarker(prov) {
    var marker = new ol.Feature(new ol.geom.Point(ol.proj.fromLonLat([parseFloat(prov.lon), parseFloat(prov.lat)])));
    marker.data = prov;
    providerMarkers.getSource().addFeature(marker);
}

function removeMarkers() {
    providerMarkers.getSource().clear();
}

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="container rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-3">
                <div class="card mb-4 rounded-3 shadow-sm border-primary">
                    <div class="card-header py-3 text-white bg-primary border-primary">
                        <h4 class="my-0 fw-normal"><span data-feather="search"></span> Services</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <label for="service_type" class="form-label">Category</label>
                                <select class="form-select" id="service_type">
                                    <option value="">Choose...</option>
                                    <?php foreach($serviceTypes as $row) { 
                                    print('<option value="'.$row->id_service_type.'">'.$row->service_type_name.'</option>');
                                    } ?>
                                </select>
                            </div>
                            <form method="post" action="<?= base_url() ?>userc/select" >
                                <div class="col-12">
                                    <label for="service" class="form-label">Service</label>
                                    <select class="form-select" id="service" name="id_service" required="">
                                        <option id="empty_service" value="">Choose...</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label for="language" class="form-label">Language</label>
                                    <select class="form-select" id="language">
                                        <option value="0">Choose...</option>
                                        <?php foreach($languages as $row) { 
                                        print('<option value="'.$row->id_language.'">'.$row->language_name.'</option>');
                                        } ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label for="distance" class="form-label">Distance</label>
                                    <select class="form-select" id="distance" required="">
                                        <option value="">Choose...</option>
                                        <option value="5" selected="true">5 Km</option>
                                        <option value="10">10 Km</option>
                                        <option value="20">20 Km</option>
                                        <option value="50">50 Km</option>
                                        <option value="100">100 Km</option>
                                    </select>
                                </div>
                                <input type="hidden" id="provider" name="id_provider">
                                <input type="hidden" id="customer" name="id_customer" value="<?= $idCustomer ?>">
                            </form>
                            <div class="col-12  mt-4">
                                <button id="btn_search" type="button" class="w-100 btn btn-lg btn-primary">Search</button>
                                <button class="d-none" type="submit" class="w-100 btn btn-lg btn-primary">Select</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="map" class="col-9 map"></div>
            <div id="popup" class="ol-popup">
                <a href="#" id="popup-closer" class="ol-popup-closer"></a>
                <div id="popup-content"></div>
            </div>
            <script>
                var userLocation = { lat: <?= $location["lat"] ?>, lon: <?= $location["lon"] ?> };
            </script>
        </div>
    </div>
</main>

<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="profile") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="profile") ? base_url()."userc/profile" : "#" ?>">
              <span data-feather="user"></span>
              Profile
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="search") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="search") ? base_url()."userc/search" : "#" ?>">
              <span data-feather="search"></span>
              Search service
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="history") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="history") ? base_url()."userc/history" : "#" ?>">
              <span data-feather="clock"></span>
              History
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="favorites") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="favorites") ? base_url()."userc/favorites" : "#" ?>">
              <span data-feather="heart"></span>
              Favorites
            </a>
          </li>
        </ul>
      </div>
    </nav>
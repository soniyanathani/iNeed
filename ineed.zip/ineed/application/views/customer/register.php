<main class="form-signup">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4 text-center">
                <form method="post" action="<?= base_url() ?>customer/register">
                <h1 class="h3 mb-3 fw-normal">Register here</h1>

                    <div class="form-floating">
                        <input type="text" class="form-control" id="fname" placeholder="firstname" name="fname" value="<?= set_value('fname') ?>">
                        <label for="fname">First Name</label>
                        <?= form_error('fname'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="text" class="form-control" id="lname" placeholder="lastname" name="lname" value="<?= set_value('lname') ?>">
                        <label for="lname">Last Name</label>
                        <?= form_error('lname'); ?>
                    </div>
                    
                    
                    
                    <div class="form-floating">
                        <input type="text" class="form-control" id="address" placeholder="address" name="address" value="<?= set_value('address') ?>">
                        <label for="address">Address</label>
                        <?= form_error('address'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="number" class="form-control" id="phone" placeholder="phonenumber" name="phone" value="<?= set_value('phone') ?>">
                        <label for="phone">Phone Number</label>
                        <?= form_error('phone'); ?>
                    </div>
                                      
                    <div class="form-floating">
                        <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email" value="<?= set_value('email') ?>">
                        <label for="email">Email address</label>
                        <?= form_error('email'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="password" class="form-control" id="password" placeholder="password" name="password">
                        <label for="password">Password</label>
                        <?= form_error('password') ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="password" class="form-control" id="confirmpassword" placeholder="confirmpassword" name="cpassword">
                        <label for="confirmpassword">Confirm Password</label>
                        <?= form_error('cpassword') ?>
                    </div>                    
                    <br/>
                    <button class="w-100 btn btn-lg btn-primary" type="submit">Register</button>
                    <p class="mt-5 mb-3 text-muted"><?= $this->session->flashdata('register_error') ?></p>
                </form>
            </div>
        </div>
    </div>
</main>
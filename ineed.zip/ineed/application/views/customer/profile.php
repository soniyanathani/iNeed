<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="container rounded bg-white mt-5 mb-5">
        <form method="post" action="<?= base_url() ?>userc/profile">
            <div class="row">
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                        <img class="rounded-circle mt-5" width="150px" src="https://i.pinimg.com/originals/0d/e7/94/0de794bbaba5b9ad5b7ffadf1dd05ac3.jpg">
                        <span class="font-weight-bold">Welcome</span>
                        <span class="text-black-50"><?= $email ?></span>
                        <!--<span> </span> -->
                    </div>
                </div>
            
                <div class="col-md-5 border-right">
                    <div class="p-3 py-5">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="text-right">Profile Settings</h4>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6"><label class="labels">Name</label><input id="fname" name="fname" type="text" class="form-control" placeholder="first name" value="<?= set_value('fname', $fname) ?>"></div>
                            <div class="col-md-6"><label class="labels">Surname</label><input id="lname" name="lname" type="text" class="form-control" value="<?= set_value('lname', $lname) ?>" placeholder="surname"></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12"><label class="labels">Phone</label><input id="phone" name="phone" type="text" class="form-control" placeholder="enter phone number" value="<?= set_value('phone', $phone) ?>"></div>
                            <div class="col-md-12"><label class="labels">Address</label><input id="address" name="address" type="text" class="form-control" placeholder="enter address line 1" value="<?= set_value('address', $address) ?>"></div>
                        </div>
                        <!-- <div class="row mt-3">
                            <div class="col-md-6"><label class="labels">Country</label><input type="text" class="form-control" placeholder="country" value=""></div>
                            <div class="col-md-6"><label class="labels">State/Region</label><input type="text" class="form-control" value="" placeholder="state"></div>
                        </div> -->
                        <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit">Save Profile</button></div>
                        <p class="mt-5 mb-3 text-muted"><?= $this->session->flashdata('register_error') ?></p>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- <div class="p-3 py-5">
                        <div class="d-flex justify-content-between align-items-center experience"><span>Edit Experience</span><span class="border px-3 p-1 add-experience"><i class="fa fa-plus"></i>&nbsp;Experience</span></div><br>
                        <div class="col-md-12"><label class="labels">Experience in Designing</label><input type="text" class="form-control" placeholder="experience" value=""></div> <br>
                        <div class="col-md-12"><label class="labels">Additional Details</label><input type="text" class="form-control" placeholder="additional details" value=""></div>
                    </div> -->
                </div>
            </div>
        </form>
    </div>
</main>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Hugo 0.87.0">
        <title>iNeed</title>
        <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('src/favicon.ico') ?>"/>

        <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/blog/">

        <!-- Bootstrap core CSS -->
        <!-- <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <!-- Custom styles for this template -->
        <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="<?= base_url('src/css/ineed.css') ?>" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <header class="blog-header py-3">
                <div class="row flex-nowrap justify-content-between align-items-center">
                    <div class="col-4 pt-1 ps-5">
                        <a class="btn btn-sm btn-outline-primary" href="<?= base_url() ?>customer/register">New customer?</a>
                    </div>
                    <div class="col-4 text-center">
                        <a class="blog-header-logo text-dark" href="<?= base_url() ?>">
                            <img src="<?= base_url('src/ineed-logo.png') ?>" alt="logo">
                        </a>
                    </div>
                    <div class="col-4 d-flex justify-content-end align-items-center pe-5">
                        <a class="link-primary" href="#" aria-label="Search">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="mx-3" role="img" viewBox="0 0 24 24"><title>Search</title><circle cx="10.5" cy="10.5" r="7.5"/><path d="M21 21l-5.2-5.2"/></svg>
                        </a>
                        <a class="btn btn-sm btn-outline-primary" href="<?= base_url() ?>customer/login">Sign in</a>
                    </div>
                </div>
            </header>

            <div class="nav-scroller py-1 mb-2">
                <nav class="nav d-flex justify-content-between">
                <a class="p-2 link-secondary" href="<?= base_url() ?>provider/login">Service Providers</a>
                <a class="p-2 link-secondary" href="#">Beauty</a>
                <a class="p-2 link-secondary" href="#">Cleaning</a>
                <a class="p-2 link-secondary" href="#">Education</a>
                <a class="p-2 link-secondary" href="#">Interior Design</a>
                <a class="p-2 link-secondary" href="#">Landscaping</a>
                <a class="p-2 link-secondary" href="#">Electrician</a>
                <a class="p-2 link-secondary" href="#">Keysmith</a>
                <a class="p-2 link-secondary" href="#">Opinion</a>
                <a class="p-2 link-secondary" href="#">Plumber</a>
                <a class="p-2 link-secondary" href="mailto:david_alfonso.vaca_buenaventura@lcieducation.net">Contact Us</a>
                </nav>
            </div>
        </div>
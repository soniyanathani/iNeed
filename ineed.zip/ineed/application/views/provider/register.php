<main class="form-signup">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4 text-center">
                <form method="post" action="<?= base_url() ?>provider/register">
                <h1 class="h3 mb-3 fw-normal">Register here</h1>
                
                	<div class="form-floating">
                        <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email" value="<?= set_value('email') ?>">
                        <label for="email">Email address</label>
                        <?= form_error('email'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="password" class="form-control" id="password" placeholder="password" name="password" value="<?= set_value('password') ?>">
                        <label for="password">Password</label>
                        <?= form_error('password'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="password" class="form-control" id="confirmpassword" placeholder="Confirm password" name="confirmpassword" value="<?= set_value('confirmpassword') ?>">
                        <label for="confirmpassword">Confirm Password</label>
                        <?= form_error('confirmpassword'); ?>
                    </div>
                    
                    
                    <div class="form-floating">
                        <input type="text" class="form-control" id="firstname" placeholder="First Name" name="firstname" value="<?= set_value('firstname') ?>">
                        <label for="firstname">First name</label>
                        <?= form_error('firstname'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="text" class="form-control" id="lastname" placeholder="Last Name" name="lastname" value="<?= set_value('lastname') ?>">
                        <label for="lastname">Last name</label>
                        <?= form_error('lastname'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="number" class="form-control" id="telephone" placeholder="Telephone number" name="telephone" value="<?= set_value('telephone') ?>">
                        <label for="telephone">Telephone</label>
                        <?= form_error('telephone'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <input type="text" class="form-control" id="address" placeholder="Address" name="address" value="<?= set_value('address') ?>">
                        <label for="address">Address</label>
                        <?= form_error('address'); ?>
                    </div>
                    
                    <div class="form-floating">
                        <select class="form-select" id="language" name="language[]" size="3" multiple>
                            <?php foreach($languages as $row) { 
                            print('<option value="'.$row->id_language.'" '.set_select('language', $row->id_language).'>'.$row->language_name.'</option>');
                            } ?>
                        </select>
                        <label for="floatingInput">Language of service</label>
                        <?= form_error('language'); ?>
 					</div> 

                    <div class="form-floating">
                        <select class="form-select" id="servicetype" name="servicetype">
                            <option id="empty_service" value="">Choose...</option>
                            <?php foreach($serviceTypes as $row) { 
                                print('<option value="'.$row->id_service_type.'" '.set_select('servicetype', $row->id_service_type).'>'.$row->service_type_name.'</option>');
                            } ?>
                        </select>
                        <label for="floatingInput">Service type</label>
                        <?= form_error('servicetype'); ?>
 					</div>
                    <br>
                    <button class="w-100 btn btn-lg btn-primary" type="submit">Register</button>
                    <p class="mt-5 mb-3 text-muted"><?= $this->session->flashdata('register_error') ?></p>
                </form>
            </div>
        </div>
    </div>
</main>
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="position-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="profile") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="profile") ? base_url()."userp/profile" : "#" ?>">
              <span data-feather="user"></span>
              Profile
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="schedule") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="schedule") ? base_url()."userp/schedule" : "#" ?>">
              <span data-feather="calendar"></span>
              Manage schedules
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="requests") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="requests") ? base_url()."userp/requests" : "#" ?>">
              <span data-feather="phone-incoming"></span>
              Requests
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?= ($this->router->fetch_method()=="history") ? "active" : "" ?>" href="<?= ($this->router->fetch_method()!="history") ? base_url()."userp/history" : "#" ?>">
              <span data-feather="clock"></span>
              History
            </a>
          </li>
        </ul>
      </div>
    </nav>
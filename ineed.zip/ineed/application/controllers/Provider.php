<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class provider extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->helper(array('form'));
        $this->load->library(['form_validation','session']);
        $this->load->database();

        if($this->session->userdata('email')) {
            redirect('userp/profile');
        }
    }

    public function login() {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('provider/login');
            $this->load->view('footer');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
 
            $account = $this->db->get_where('account',['email' => $email])->row();
 
            if(!$account) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.');
                redirect(uri_string());
            }

            if(!password_verify($password,$account->password)) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.');
                redirect(uri_string());
            }

            $user = $this->db->get_where('service_provider',['id_account' => $account->id_account])->row();

            $data = array(
                'provider_id' => $user->id_service_provider,
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $account->email,
                'rol' => "provider",
            );

            $this->session->set_userdata($data);

            redirect('userp/profile');
        }
    }

    public function register() {
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('address', 'Full Address', 'required');
        $this->form_validation->set_rules('telephone', 'Phone Number', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required|matches[password]');
        
        $this->form_validation->set_rules('language[]', 'Laguage', 'required');
        $this->form_validation->set_rules('servicetype', 'Service type', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            // Load all services types
            $data["serviceTypes"] = $this->db->get('service_type')->result();
            // Load all services types
            $data["languages"] = $this->db->get('language')->result();
            
            $this->load->view('header');
            $this->load->view('provider/register', $data);
            $this->load->view('footer');
        } else {
            
            $data = array(
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            ) ;
            
            $this->db->insert('account', $data);
            
            $idAccount = $this->db->insert_id();

            $address = urlencode($this->input->post('address'));
            $curl = curl_init();

            $url = "https://nominatim.openstreetmap.org/search?q={$address},+montreal&format=json&polygon=1&addressdetails=1";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_REFERER, $url);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36");
            $result = curl_exec($ch);
            curl_close($ch);
            $geoData = json_decode($result);
            
            $data = array(
                'first_name' => $this->input->post('firstname'),
                'last_name' => $this->input->post('lastname'),
                'telephone' => $this->input->post('telephone'),
                'address' => $this->input->post('address'),
                'status' => "ACT",
                'lat' => $geoData[0]->lat,
                'lon' => $geoData[0]->lon,
                'id_account' => $idAccount,
            );
            
            $this->db->insert('service_provider', $data);

            $idUser = $this->db->insert_id();
            $languages = $this->input->post('language');

            $data = array('id_service_provider' => $idUser,);

            foreach($languages as $language) {
                $data['id_language'] = $language;
                $this->db->insert('service_provider_language', $data);
            }
            
            redirect('provider/login');
        }
    }
    
}
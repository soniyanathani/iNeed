<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserC extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->helper(array('form'));
        $this->load->library(['form_validation','session']);
        $this->load->database();

        if(!$this->session->userdata('email')) {
            redirect('customer/login');
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('/');
    }

    public function change_password() {
        
    }

    public function profile() {
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('address', 'Full Address', 'required');
        $this->form_validation->set_rules('phone', 'Phone Number', 'required');

        if ($this->form_validation->run() == FALSE) {
            $rst = $this->db->get_where('customer', array('id_customer' => $this->session->userdata('customer_id')))->result();
            $customer = $rst[0];
            $data = array(
                "fname" => $customer->first_name,
                "lname" => $customer->last_name,
                "phone" => $customer->telephone,
                "address" => $customer->address,
                "email" => $this->session->userdata('email'),
            );
            $this->load->view('header_user');
            $this->load->view('customer/menu');
            $this->load->view('customer/profile', $data);
            $this->load->view('footer_user');
        }  else {
            $address = urlencode($this->input->post('address'));
            $curl = curl_init();

            $url = "https://nominatim.openstreetmap.org/search?q={$address},+montreal&format=json&polygon=1&addressdetails=1";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_REFERER, $url);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36");
            $result = curl_exec($ch);
            curl_close($ch);
            $geoData = json_decode($result);
          
            $data = array(
                'first_name' => $this->input->post('fname'),
                'last_name' => $this->input->post('lname'),
                'telephone' => $this->input->post('phone'),
                'address' => $this->input->post('address'),
                'lat' => $geoData[0]->lat,
                'lon' => $geoData[0]->lon,
            );
           
            $this->db->where('id_customer', $this->session->userdata('customer_id'));
            $this->db->update('customer', $data);

            // Update sesion data
            $this->session->set_userdata('first_name', $data['first_name']);
            $this->session->set_userdata('last_name', $data['last_name']);
            $this->session->set_userdata('lat', $data['lat']);
            $this->session->set_userdata('lon', $data['lon']);

            redirect('userc/profile');
        }
    }

    public function search() {
        $this->form_validation->set_rules('id_service', 'Service', 'required');
        $this->form_validation->set_rules('id_provider', 'Provider', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            // Load all services types
            $data["serviceTypes"] = $this->db->get('service_type')->result();
            // Load all services types
            $data["languages"] = $this->db->get('language')->result();
            $data["idCustomer"] = $this->session->userdata('customer_id');
            $data["location"] = array("lat" => $this->session->userdata('lat'), "lon" => $this->session->userdata('lon'));
            
            $this->load->view('header_user');
            $this->load->view('customer/menu');
            $this->load->view('customer/search', $data);
            $this->load->view('footer_user');
        } else {
            $service = $this->input->post('id_service');
            $serviceProvider = $this->input->post('id_provider');
            // Redirect to schedule page
        }
    }

    public function history() {
        $this->load->view('header_user');
        $this->load->view('customer/menu');
        $this->load->view('blank');
        $this->load->view('footer_user');
    }

    public function favorites() {
        $this->load->view('header_user');
        $this->load->view('customer/menu');
        $this->load->view('blank');
        $this->load->view('footer_user');
    }
}

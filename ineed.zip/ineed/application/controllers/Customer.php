<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->helper(array('form'));
        $this->load->library(['form_validation','session']);
        $this->load->database();

        if($this->session->userdata('email')) {
            redirect('userc/profile');
        }
    }

    public function login() {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('customer/login');
            $this->load->view('footer');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
 
            $account = $this->db->get_where('account',['email' => $email])->row();
 
            if(!$account) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.');
                redirect(uri_string());
            }

            if(!password_verify($password,$account->password)) {
                $this->session->set_flashdata('login_error', 'Please check your email or password and try again.');
                redirect(uri_string());
            }

            $user = $this->db->get_where('customer',['id_account' => $account->id_account])->row();

            $data = array(
                'customer_id' => $user->id_customer,
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $account->email,
                'lat' => $user->lat,
                'lon' => $user->lon,
                'rol' => "customer",
            );

            $this->session->set_userdata($data);

            redirect('userc/profile');
        }
    }

    public function register() {
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('address', 'Full Address', 'required');
        $this->form_validation->set_rules('phone', 'Phone Number', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('customer/register');
            $this->load->view('footer');
        } else {
           
            $data = array(
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            ) ;
          
            $this->db->insert('account', $data);
            
            $idAccount = $this->db->insert_id();

            $address = urlencode($this->input->post('address'));
            $curl = curl_init();

            $url = "https://nominatim.openstreetmap.org/search?q={$address},+montreal&format=json&polygon=1&addressdetails=1";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_REFERER, $url);
            curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36");
            $result = curl_exec($ch);
            curl_close($ch);
            $geoData = json_decode($result);
          
            $data = array(
                'first_name' => $this->input->post('fname'),
                'last_name' => $this->input->post('lname'),
                'telephone' => $this->input->post('phone'),
                'address' => $this->input->post('address'),
                'status' => "ACT",
                'lat' => $geoData[0]->lat,
                'lon' => $geoData[0]->lon,
                'id_account' => $idAccount,
            );
           
            $this->db->insert('customer', $data);
            
            redirect('customer/login');
        }
    }

}
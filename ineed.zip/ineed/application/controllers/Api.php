<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function getservices($idServiceType) {
        $services = $this->db->get_where('service',['id_service_type' => $idServiceType])->result();
        print(json_encode($services));
    }

    public function getproviders($idCustomer, $idService, $distance, $language) {
        $languageJoin = ""; 
        if($language) {
            $languageJoin = "JOIN service_provider_language SPL ON(SP.id_service_provider = SPL.id_service_provider AND SPL.id_language = {$language})";
        }

        $statement = "SELECT SP.*, 
            SQRT( POW(111 * (SP.lat - C.lat), 2) + POW(111 * (C.lon - SP.lon) * COS(SP.lat / 57.3), 2)) AS distance 
        FROM customer C, service_provider SP 
        JOIN service_provider_service SPS ON(SP.id_service_provider = SPS.id_service_provider AND SPS.id_service = {$idService})
        {$languageJoin}
        WHERE C.id_customer = {$idCustomer}
        HAVING distance < {$distance}
        ORDER BY distance";
        $providers = $this->db->query($statement)->result();
        print(json_encode($providers));
    }
}


